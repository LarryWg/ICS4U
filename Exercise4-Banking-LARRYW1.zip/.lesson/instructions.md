# Instructions  

Create a simple banking program using a BankAccount class that has one instance attribute for a balance. It should have 2 constructors, one to initialize the balance to zero (default) and another to assign the balance a value based on user input. Methods will include a getter for the balance, a deposit value returning method (function) and a withdrawal value returning method (function). In this method, make sure a person doesn’t withdraw more than the balance.

Write the driver class that asks the user for their balance, then creates an account object for that “person”. Have a simple menu that will ask them to deposit, withdraw or quit (could be a helper method in the Banking class), then call the appropriate method based on their choice. 

BONUS (level 4): Add bullet proofing (exception handling) of input, along with another feature or two to make it more “useful” for someone to actually USE.

  